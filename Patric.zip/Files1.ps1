# Disabling Firewall For All Profiles
& {
    Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False
}

# Installing CRD Host, Chrome And DirectX Via Chocolatey
choco install chrome-remote-desktop-host -y --ignore-checksums
choco install directx -y --ignore-checksums
choco install googlechrome -y --ignore-checksums

# Navigating And Downloading Essentials To The Documents Directory
cd C:\Users\$Env:USERNAME\Documents
Invoke-WebRequest -Uri "https://drive.usercontent.google.com/download?id=1q1huWc4ljQyh3_JU_B4ZHikIlqKJ8aso&export=download&authuser=0&confirm=t&uuid=fdbceb6f-1b4d-49c1-9128-d38cf855055b&at=APZUnTVUm1AGqItiY6LCUoXfH13d%3A1716612457921" -Outfile Document1.zip
7z x Document1.zip -y

# Start Essential Applications
Start-Process "C:\Users\runneradmin\Documents\LibreOffice_26.8.1_Win_x86-64.msi"
Start-Process .

# Creating Shortcuts
New-Item -ItemType SymbolicLink -Target "C:\Users\$Env:USERNAME\Documents\Documents\Blender\blender-2.93.9-windows-x64\blender.exe" -Path "C:\Users\$Env:USERNAME\Desktop\Blender.lnk"
New-Item -ItemType SymbolicLink -Target "C:\Users\$Env:USERNAME\Documents\Documents\AssetStudioGUI\AssetStudioGUI.exe" -Path "C:\Users\$Env:USERNAME\Desktop\AssetStudioGUI.lnk"
